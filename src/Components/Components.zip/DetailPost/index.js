import PostContainer from "./DetailPostContainer";

export default PostContainer;